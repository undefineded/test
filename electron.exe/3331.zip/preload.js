// All of the Node.js APIs are available in the preload process.
// It has the same sandbox as a Chrome extension.
const {ipcRenderer} = require('electron')
window.addEventListener('DOMContentLoaded', () => {
  setTimeout(()=>{
    loadFile()
  },2000)
})

window.loadFile = function () {
  let myDn = ipcRenderer.sendSync('reloadDn', '1')
  if (myDn.code!==200) {
    alert(myDn.msg)
  }
  window._DN = myDn.data
  window.dnList()
}

window.dnList = function () {
  $('#list').html('')
  let list1 = ''
  let templateHtml = (l, index) => {
    return `<li><p>${l.tm}</p>
<p style="padding: 0 10px;font-size: 16px">
${l.dn}
<span style="font-size: 12px;color: red;padding-left: 20px;cursor: pointer" onclick="window.delListOne(${index})">删除</span>
</p></li>`
  }
  for(let i = 0;i< window._DN.length;i++){
    list1+=templateHtml(window._DN[i],i)
  }
  $('#list').html(list1)
}

window.delListOne = function(index){
  window._DN.splice(index,1)
  window.dnList()
}

window.add = function () {
  let tm = $('#tm').val()
  let dn = $('#dn').val()
  window._DN.push({
    tm:tm,
    dn:dn
  })
  window.dnList()
}

window.save = function () {
  let info = ipcRenderer.sendSync('saveDn', window._DN)
  alert(info.msg)
}