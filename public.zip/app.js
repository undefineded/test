const express = require('express');
const app = express();
const path = require('path');
const ejs = require('ejs');
const ffmpeg = require('fluent-ffmpeg')
const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({extended: false}));
// app.use(bodyParser.json());
app.use(bodyParser.json({ "limit":"10000kb"}));
app.use(express.static(path.join(__dirname, 'public')));
app.set('views', path.join(__dirname, 'public'));
app.set('views', './public');
app.set('view engine', 'html');
app.engine('html', ejs.renderFile);


ffmpeg

app.get('/', function (req, res) {
    res.render('index-1.html');
});

app.post('/savePie', function (req, res) {
    console.log(req.body.index, req.body.base)
    res.send({code:200,msg:"success"})
});
app.listen(2234, function () {
    console.log('服务启动-----------2234')
});