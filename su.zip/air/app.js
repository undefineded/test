//var mysql = require('mysql');
var fs = require('fs');
var express = require('express');
var app = express();
// var multer = require('multer');//文件流接收文件
var path = require('path');
var ejs = require('ejs');
// var gm = require('gm').subClass({imageMagick: true});//图片压缩c#库
var bodyParser = require('body-parser');
// var nodemailer  = require('nodemailer');//发邮件引用
app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));
app.set('views', path.join(__dirname, 'public'));
app.set('views', './public');
app.set('view engine', 'html');
app.engine('html', ejs.renderFile);

app.get('/', function (req, res) {
    res.render('index');
});
app.get('*', function(req, res){
  res.sendFile( __dirname + "/public/" + "index.html" );
});
app.listen(80, function () {
    console.log('服务启动-----------80')
});